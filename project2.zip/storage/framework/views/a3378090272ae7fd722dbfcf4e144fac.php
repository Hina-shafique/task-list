<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project 2</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css', 'resources/js/app.js'); ?>
</head>
<body>
    <section class="max-w-4xl mx-auto mt-10 p-5 bg-white container">
        <?php echo e($slot); ?>

    </section>
</body>
</html><?php /**PATH C:\Users\nas\Herd\project2\resources\views/components/layout.blade.php ENDPATH**/ ?>