<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section>
        <h1 class="text-2xl font-semibold"><?php echo e($book->title); ?></h1>
        <p class="text-xl text-gray-500">by : <?php echo e($book->author); ?></p>
        <div>
            <div class="font-bold text-xl text-gray-600">
                <?php echo e(str_repeat('★', floor($averageRating))); ?>

                <?php echo e(str_repeat('☆', 5 - floor($averageRating))); ?>

            </div>
            <div class="text-sm text-gray-600">
                <p>out of <?php echo e($totalReviews); ?> Reviews. </p>
            </div>
            <div>
                <a href="/books/<?php echo e($book->id); ?>/create" class="underline text-gray-500">Add a review</a>
            </div>
        </div>
    </section>
    <section class="mt-4">
        <h1 class="text-2xl font-semibold">Reviews</h1>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-3 gap-x-6 border hover:border-gray-600 p-5 rounded-xl">
                <p class="text-gray-500"><?php echo e($review->review); ?></p>
                <div class="font-bold text-xl text-gray-600">
                    <?php echo e(str_repeat('★', floor($review->rating))); ?>

                    <?php echo e(str_repeat('☆', 5 - floor($review->rating))); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nas\Herd\project2\resources\views/books/show.blade.php ENDPATH**/ ?>