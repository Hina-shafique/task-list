<?php if(isset($attributes['href'])): ?>
    <a href="<?php echo e($attributes['href']); ?>" <?php echo e($attributes->merge(['class' => 'px-4 py-2 bg-white-100 border text-gray-700 rounded-md hover:bg-gray-400'])); ?>>
        <?php echo e($slot); ?>

    </a>
<?php else: ?>
    <button <?php echo e($attributes->merge(['class' => 'px-4 py-2 bg-white-100 border text-gray-700 rounded-md hover:bg-gray-400','type'=>'submit'])); ?>>
        <?php echo e($slot); ?>

    </button>
<?php endif; ?>
<?php /**PATH C:\Users\nas\Herd\project2\resources\views/components/button.blade.php ENDPATH**/ ?>