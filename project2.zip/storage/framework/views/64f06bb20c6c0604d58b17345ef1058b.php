<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['books']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['books']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="gap-x-6 flex border hover:border-gray-600 p-5 rounded-xl">
        <div class="flex-1">
            <a href="/books/<?php echo e($book->id); ?>">
            <h2 class="text-lg font-semibold"><?php echo e($book->title); ?></h2>
            <p class="text-sm text-gray-500">by : <?php echo e($book->author); ?></p>
            </a>
        </div>
        <div class="flex flex-col items-center">
            <div class="font-bold text-xl text-gray-600">
                <?php echo e(str_repeat('★', floor($book->reviews_avg_rating ?? 0))); ?>

                <?php echo e(str_repeat('☆', 5 - floor($book->reviews_avg_rating ?? 0))); ?>

            </div>
            <div class="text-sm text-gray-600">
                out of <?php echo e($book->reviews_count ?? 0); ?> reviews
            </div>
        </div>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\nas\Herd\project2\resources\views/components/section-wide.blade.php ENDPATH**/ ?>