<a href="/" 
    class="border rounded-md <?php echo e($class); ?>">
    <?php echo e($slot); ?>

</a><?php /**PATH C:\Users\nas\Herd\project2\resources\views/components/nav.blade.php ENDPATH**/ ?>