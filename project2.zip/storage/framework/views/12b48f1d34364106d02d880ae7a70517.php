<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section>
       <h1 class="text-bold text-3xl mb-4 ">Books</h1>
    </section>
    <section class="mt-12"> 
        <form method="POST" action="/" class="mb-6 flex space-x-2">
            <input 
            name="search" 
            id="search" 
            placeholder="Search Book" 
            class="border rounded-md px-4 py-2 w-full focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> Search  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/']); ?> Claer  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
        </form>
    </section>
    <section>
    <div class="flex space-x-4 bg-gray-100 p-4 text-center">
            <a href="/" 
               class="px-10 py-4 border <?php echo e(request()->is('/') ? 'bg-white text-black' : ''); ?> rounded-md">
                Latest
            </a>
            <a href="/popular" 
               class="px-10 py-2 border rounded-md <?php echo e(request()->is('/popular') ? 'bg-white text-black' : ''); ?>">
                Popular Last Month
            </a>
            <a href="/last" 
               class="px-4 py-2 border rounded-md">
                Popular Last 6 Months
            </a>
            <a href="/rated" 
               class="px-4 py-2 border rounded-md">
                Highest Rated Last Month
            </a>
            <a href="/month" 
               class="px-4 py-2 border rounded-md">
                Highest Rated Last 6 Months
            </a>
        </div>
    </section>
    <section class="mt-2 space-y-4 shadow">
        <?php if (isset($component)) { $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-wide','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-wide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $attributes = $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $component = $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-wide','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-wide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $attributes = $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $component = $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-wide','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-wide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $attributes = $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $component = $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-wide','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-wide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $attributes = $__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__attributesOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8)): ?>
<?php $component = $__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8; ?>
<?php unset($__componentOriginal90a2f7bbfc6fd622ed2192c76ee604f8); ?>
<?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\nas\Herd\project2\resources\views/welcome.blade.php ENDPATH**/ ?>