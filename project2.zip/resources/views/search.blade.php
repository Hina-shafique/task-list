<x-layout>
<section>
       <h1 class="text-bold text-3xl mb-4 ">Results</h1>
    </section>
<section class="space-y-4 shadow">
        <x-section-wide :$books />
    </section>
</x-layout>